from django.apps import AppConfig


class BitlyConfig(AppConfig):
    name = 'bitly'
